import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { initialPortfolioData } from './src/data/portfolioData';
import { PortfolioData } from './src/types/portfolio';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Répertoire de stockage des données sur le serveur
const DATA_DIR = path.resolve(__dirname, 'server-data');
const DATA_FILE = path.join(DATA_DIR, 'portfolio.json');
const AUTH_FILE = path.join(DATA_DIR, 'admin-auth.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initialisation sécurisée du mot de passe administrateur
interface AuthConfig {
  passwordHash: string;
  sessions: string[]; // jetons de session actifs
}

const hashPassword = (pwd: string) => {
  return crypto.createHash('sha256').update(pwd).digest('hex');
};

const getAuthConfig = (): AuthConfig => {
  if (fs.existsSync(AUTH_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(AUTH_FILE, 'utf-8'));
    } catch {
      // fallback
    }
  }
  // Mot de passe initial par défaut (modifiable via l'interface d'administration ou variable d'environnement)
  const defaultPassword = process.env.ADMIN_PASSWORD || 'geomaticien2026';
  const initialConfig: AuthConfig = {
    passwordHash: hashPassword(defaultPassword),
    sessions: [],
  };
  fs.writeFileSync(AUTH_FILE, JSON.stringify(initialConfig, null, 2), 'utf-8');
  return initialConfig;
};

const saveAuthConfig = (cfg: AuthConfig) => {
  fs.writeFileSync(AUTH_FILE, JSON.stringify(cfg, null, 2), 'utf-8');
};

// Initialisation des données du portfolio (collections vides par défaut selon consignes)
const getPortfolioData = (): PortfolioData => {
  if (fs.existsSync(DATA_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'));
    } catch {
      // fallback
    }
  }
  // Sauvegarde initiale
  fs.writeFileSync(DATA_FILE, JSON.stringify(initialPortfolioData, null, 2), 'utf-8');
  return initialPortfolioData;
};

const savePortfolioData = (data: PortfolioData) => {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
};

// Middleware de vérification d'authentification administrateur
const requireAdminAuth = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      error: 'Accès refusé : jeton d\'authentification administrateur manquant.',
    });
  }

  const token = authHeader.split(' ')[1];
  const authCfg = getAuthConfig();

  if (!authCfg.sessions.includes(token)) {
    return res.status(401).json({
      error: 'Accès refusé : session administrateur invalide ou expirée.',
    });
  }

  next();
};

async function startServer() {
  const app = express();

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // ==========================================
  // ROUTES PUBLIQUES (LECTURE SEULE POUR VISITEURS)
  // ==========================================

  // Récupérer le contenu complet du portfolio (Public)
  app.get('/api/portfolio', (_req: Request, res: Response) => {
    try {
      const data = getPortfolioData();
      res.json(data);
    } catch {
      res.status(500).json({ error: 'Erreur lors de la lecture des données du portfolio.' });
    }
  });

  // ==========================================
  // ROUTES AUTHENTIFICATION ADMINISTRATEUR
  // ==========================================

  // Connexion administrateur
  app.post('/api/admin/login', (req: Request, res: Response) => {
    const { password } = req.body;
    if (!password) {
      return res.status(400).json({ error: 'Le mot de passe est obligatoire.' });
    }

    const authCfg = getAuthConfig();
    const inputHash = hashPassword(password);

    if (inputHash !== authCfg.passwordHash) {
      return res.status(401).json({ error: 'Mot de passe administrateur incorrect.' });
    }

    // Créer un jeton de session sécurisé
    const token = crypto.randomBytes(32).toString('hex');
    authCfg.sessions.push(token);
    // Limiter aux 10 dernières sessions
    if (authCfg.sessions.length > 10) {
      authCfg.sessions = authCfg.sessions.slice(-10);
    }
    saveAuthConfig(authCfg);

    res.json({
      success: true,
      token,
      message: 'Authentification réussie.',
    });
  });

  // Déconnexion administrateur
  app.post('/api/admin/logout', (req: Request, res: Response) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      const authCfg = getAuthConfig();
      authCfg.sessions = authCfg.sessions.filter((s) => s !== token);
      saveAuthConfig(authCfg);
    }
    res.json({ success: true, message: 'Déconnexion effectuée.' });
  });

  // Vérifier la validité de la session en cours
  app.get('/api/admin/verify', (req: Request, res: Response) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.json({ authenticated: false });
    }

    const token = authHeader.split(' ')[1];
    const authCfg = getAuthConfig();
    const isValid = authCfg.sessions.includes(token);
    res.json({ authenticated: isValid });
  });

  // ==========================================
  // ROUTES PROTÉGÉES (ÉCRITURE RÉSERVÉE À L'ADMIN)
  // ==========================================

  // Mettre à jour l'ensemble des données du portfolio
  app.put('/api/admin/portfolio', requireAdminAuth, (req: Request, res: Response) => {
    try {
      const newData: PortfolioData = req.body;
      if (!newData || !newData.profile) {
        return res.status(400).json({ error: 'Structure de données invalide.' });
      }

      savePortfolioData(newData);
      res.json({
        success: true,
        message: 'Données du portfolio enregistrées avec succès.',
        data: newData,
      });
    } catch {
      res.status(500).json({ error: 'Erreur lors de l\'enregistrement des données.' });
    }
  });

  // Modifier le mot de passe administrateur
  app.post('/api/admin/change-password', requireAdminAuth, (req: Request, res: Response) => {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Veuillez fournir le mot de passe actuel et le nouveau mot de passe.' });
    }
    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'Le nouveau mot de passe doit comporter au moins 6 caractères.' });
    }

    const authCfg = getAuthConfig();
    if (hashPassword(currentPassword) !== authCfg.passwordHash) {
      return res.status(401).json({ error: 'Le mot de passe actuel est erroné.' });
    }

    authCfg.passwordHash = hashPassword(newPassword);
    saveAuthConfig(authCfg);

    res.json({ success: true, message: 'Mot de passe administrateur modifié avec succès.' });
  });

  // ==========================================
  // GESTION DU FRONTEND VITE (DEV vs PROD)
  // ==========================================

  if (!isProduction) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Serveur démarré sur http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Erreur au démarrage du serveur :', err);
});
