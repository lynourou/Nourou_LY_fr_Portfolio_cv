import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import {
  PortfolioData,
  ProfileData,
  AboutData,
  SkillCategory,
  ProjectDetail,
  ExperienceItem,
  FieldworkItem,
  CartoItem,
  EducationItem,
  ContactData,
} from '../types/portfolio';
import { initialPortfolioData } from '../data/portfolioData';

interface PortfolioContextType {
  data: PortfolioData;
  isLoading: boolean;
  isAdmin: boolean;
  adminToken: string | null;
  // Fonctions d'authentification
  login: (password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  checkAuthStatus: () => Promise<boolean>;
  changeAdminPassword: (currentPassword: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  // Sauvegarde globale sécurisée (réservée à l'administrateur authentifié)
  savePortfolio: (newData: PortfolioData) => Promise<{ success: boolean; error?: string }>;
  // Fonctions de mise à jour pour l'espace administration
  updateProfile: (profile: ProfileData) => Promise<boolean>;
  updateAbout: (about: AboutData) => Promise<boolean>;
  updateProfileAndAbout: (profile: ProfileData, about: AboutData) => Promise<{ success: boolean; error?: string }>;
  updateContact: (contact: ContactData) => Promise<boolean>;
  // Projets
  saveProject: (project: ProjectDetail) => Promise<boolean>;
  deleteProject: (projectId: string) => Promise<boolean>;
  // Expériences
  saveExperience: (experience: ExperienceItem) => Promise<boolean>;
  deleteExperience: (experienceId: string) => Promise<boolean>;
  // Terrain
  saveFieldwork: (fieldwork: FieldworkItem) => Promise<boolean>;
  deleteFieldwork: (fieldworkId: string) => Promise<boolean>;
  // Cartes
  saveCarto: (carto: CartoItem) => Promise<boolean>;
  deleteCarto: (cartoId: string) => Promise<boolean>;
  // Compétences
  saveSkills: (skills: SkillCategory[]) => Promise<boolean>;
  // Formation
  saveEducation: (education: EducationItem) => Promise<boolean>;
  deleteEducation: (educationId: string) => Promise<boolean>;
  // Recharger les données publiques
  refreshData: () => Promise<void>;
}

const PortfolioContext = createContext<PortfolioContextType | undefined>(undefined);

const ADMIN_TOKEN_KEY = 'geomaticien_admin_token';

export const PortfolioProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [data, setData] = useState<PortfolioData>(initialPortfolioData);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [adminToken, setAdminToken] = useState<string | null>(() => {
    return sessionStorage.getItem(ADMIN_TOKEN_KEY) || localStorage.getItem(ADMIN_TOKEN_KEY);
  });
  const [isAdmin, setIsAdmin] = useState<boolean>(false);

  // Charger les données publiques depuis l'API GET /api/portfolio
  const refreshData = useCallback(async () => {
    try {
      const res = await fetch('/api/portfolio');
      if (res.ok) {
        const json = await res.json();
        setData(json);
      }
    } catch (err) {
      console.error('Erreur lors de la récupération des données du portfolio :', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Vérifier la validité du token admin au démarrage
  const checkAuthStatus = useCallback(async (): Promise<boolean> => {
    const token = sessionStorage.getItem(ADMIN_TOKEN_KEY) || localStorage.getItem(ADMIN_TOKEN_KEY);
    if (!token) {
      setIsAdmin(false);
      setAdminToken(null);
      return false;
    }

    try {
      const res = await fetch('/api/admin/verify', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const json = await res.json();
      if (json.authenticated) {
        setIsAdmin(true);
        setAdminToken(token);
        return true;
      } else {
        sessionStorage.removeItem(ADMIN_TOKEN_KEY);
        localStorage.removeItem(ADMIN_TOKEN_KEY);
        setIsAdmin(false);
        setAdminToken(null);
        return false;
      }
    } catch {
      setIsAdmin(false);
      return false;
    }
  }, []);

  useEffect(() => {
    refreshData();
    checkAuthStatus();
  }, [refreshData, checkAuthStatus]);

  // Connexion administrateur
  const login = async (password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const json = await res.json();

      if (res.ok && json.token) {
        localStorage.setItem(ADMIN_TOKEN_KEY, json.token);
        sessionStorage.setItem(ADMIN_TOKEN_KEY, json.token);
        setAdminToken(json.token);
        setIsAdmin(true);
        return { success: true };
      } else {
        return { success: false, error: json.error || 'Mot de passe incorrect.' };
      }
    } catch {
      return { success: false, error: 'Impossible de contacter le serveur.' };
    }
  };

  // Déconnexion administrateur
  const logout = async () => {
    if (adminToken) {
      try {
        await fetch('/api/admin/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${adminToken}` },
        });
      } catch {
        // ignorer
      }
    }
    sessionStorage.removeItem(ADMIN_TOKEN_KEY);
    localStorage.removeItem(ADMIN_TOKEN_KEY);
    setAdminToken(null);
    setIsAdmin(false);
  };

  // Modifier le mot de passe administrateur
  const changeAdminPassword = async (currentPassword: string, newPassword: string) => {
    if (!adminToken) {
      return { success: false, error: 'Session administrateur expirée.' };
    }

    try {
      const res = await fetch('/api/admin/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const json = await res.json();
      if (res.ok) {
        return { success: true };
      }
      return { success: false, error: json.error || 'Erreur lors de la modification du mot de passe.' };
    } catch {
      return { success: false, error: 'Erreur réseau.' };
    }
  };

  // Sauvegarder les données de façon sécurisée (PUT protégé)
  const savePortfolio = async (newData: PortfolioData): Promise<{ success: boolean; error?: string }> => {
    if (!adminToken) {
      return { success: false, error: 'Accès refusé : session administrateur requise.' };
    }

    try {
      const res = await fetch('/api/admin/portfolio', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify(newData),
      });

      const json = await res.json();
      if (res.ok) {
        setData(newData);
        return { success: true };
      } else {
        if (res.status === 401) {
          setIsAdmin(false);
          setAdminToken(null);
        }
        return { success: false, error: json.error || 'Erreur lors de la sauvegarde.' };
      }
    } catch {
      return { success: false, error: 'Impossible de joindre le serveur.' };
    }
  };

  // Fonctions pratiques pour l'espace admin
  const updateProfile = async (profile: ProfileData) => {
    const updated = { ...data, profile };
    const res = await savePortfolio(updated);
    return res.success;
  };

  const updateAbout = async (about: AboutData) => {
    const updated = { ...data, about };
    const res = await savePortfolio(updated);
    return res.success;
  };

  const updateProfileAndAbout = async (profile: ProfileData, about: AboutData) => {
    const updated = { ...data, profile, about };
    const res = await savePortfolio(updated);
    return res;
  };

  const updateContact = async (contact: ContactData) => {
    const updated = { ...data, contact };
    const res = await savePortfolio(updated);
    return res.success;
  };

  const saveProject = async (project: ProjectDetail) => {
    const exists = data.projects.some((p) => p.id === project.id);
    const projects = exists
      ? data.projects.map((p) => (p.id === project.id ? project : p))
      : [project, ...data.projects];
    const res = await savePortfolio({ ...data, projects });
    return res.success;
  };

  const deleteProject = async (projectId: string) => {
    const projects = data.projects.filter((p) => p.id !== projectId);
    const res = await savePortfolio({ ...data, projects });
    return res.success;
  };

  const saveExperience = async (experience: ExperienceItem) => {
    const exists = data.experiences.some((e) => e.id === experience.id);
    const experiences = exists
      ? data.experiences.map((e) => (e.id === experience.id ? experience : e))
      : [experience, ...data.experiences];
    const res = await savePortfolio({ ...data, experiences });
    return res.success;
  };

  const deleteExperience = async (experienceId: string) => {
    const experiences = data.experiences.filter((e) => e.id !== experienceId);
    const res = await savePortfolio({ ...data, experiences });
    return res.success;
  };

  const saveFieldwork = async (fieldwork: FieldworkItem) => {
    const exists = data.fieldwork.some((f) => f.id === fieldwork.id);
    const fieldworkList = exists
      ? data.fieldwork.map((f) => (f.id === fieldwork.id ? fieldwork : f))
      : [fieldwork, ...data.fieldwork];
    const res = await savePortfolio({ ...data, fieldwork: fieldworkList });
    return res.success;
  };

  const deleteFieldwork = async (fieldworkId: string) => {
    const fieldwork = data.fieldwork.filter((f) => f.id !== fieldworkId);
    const res = await savePortfolio({ ...data, fieldwork });
    return res.success;
  };

  const saveCarto = async (carto: CartoItem) => {
    const exists = data.cartography.some((c) => c.id === carto.id);
    const cartography = exists
      ? data.cartography.map((c) => (c.id === carto.id ? carto : c))
      : [carto, ...data.cartography];
    const res = await savePortfolio({ ...data, cartography });
    return res.success;
  };

  const deleteCarto = async (cartoId: string) => {
    const cartography = data.cartography.filter((c) => c.id !== cartoId);
    const res = await savePortfolio({ ...data, cartography });
    return res.success;
  };

  const saveSkills = async (skills: SkillCategory[]) => {
    const res = await savePortfolio({ ...data, skills });
    return res.success;
  };

  const saveEducation = async (education: EducationItem) => {
    const exists = data.education.some((e) => e.id === education.id);
    const educationList = exists
      ? data.education.map((e) => (e.id === education.id ? education : e))
      : [education, ...data.education];
    const res = await savePortfolio({ ...data, education: educationList });
    return res.success;
  };

  const deleteEducation = async (educationId: string) => {
    const education = data.education.filter((e) => e.id !== educationId);
    const res = await savePortfolio({ ...data, education });
    return res.success;
  };

  return (
    <PortfolioContext.Provider
      value={{
        data,
        isLoading,
        isAdmin,
        adminToken,
        login,
        logout,
        checkAuthStatus,
        changeAdminPassword,
        savePortfolio,
        updateProfile,
        updateAbout,
        updateProfileAndAbout,
        updateContact,
        saveProject,
        deleteProject,
        saveExperience,
        deleteExperience,
        saveFieldwork,
        deleteFieldwork,
        saveCarto,
        deleteCarto,
        saveSkills,
        saveEducation,
        deleteEducation,
        refreshData,
      }}
    >
      {children}
    </PortfolioContext.Provider>
  );
};

export const usePortfolio = () => {
  const context = useContext(PortfolioContext);
  if (!context) {
    throw new Error('usePortfolio doit être utilisé au sein d\'un PortfolioProvider');
  }
  return context;
};
